rPeANUt is a RISC version of the PeANUt computer.   
The simulator was written completely in Java at the beginning of 2011 
and has been refined and improved over the last few years.
The source code is GPL and available in the jar file. 
