import java.util.ArrayList;
import java.util.HashMap;


public class Defines extends HashMap<String, ArrayList<Object>>{

	
	
	
}
